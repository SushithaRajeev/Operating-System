/**
 * @file shell.c
 * @brief shell.c
 * @author
 * @date 06-Sep-2019
 *
 */

/********************************************************************
 * Headers
 *******************************************************************/

#include <stdio.h>
#include <error.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "shell.h"
#include "file.h"
#include "aliases.h"

#include "history.h"
#include "log.h"

bool tsh_debug;
bool exit_signal;

static char *hist[STORE_TOTAL_HISTORY];
static int current = 0;
static int history_count = 0;
static char *preserve_string = NULL;
static bool re_execution_command = false;

shell_info_t s_info = {
    .terminator = ">",
    .shell_name = "toyshell"
};

static aliases_hold_t alias_hold[STORE_TOTAL_ALIASES];

/********************************************************************
 * Decelerations
 *******************************************************************/

/* List of commands registered */
command_t commands[] = {
        {"stop",            cmd_stop,               "NILL",             "exit a command shell"},
        {"setshellname",    cmd_setshellname,       "string",           "To rename the shell"},
        {"setterminator",   cmd_setterminator,      "string",           "set the terminator"},
        {"history",         cmd_history,            "NILL",             "display the history of current session"},
        {"clear_history",   cmd_clear_history,      "NILL",             "clear the history of current session"},
        {"!",               cmd_history_execute,    "int",              "re-execute the history command"},
        {"newname",         cmd_newname,            "strings",          "store the new aliases"},
        {"newnames",        cmd_display_newname,    "NILL",             "display the aliases stored"},
        {"savenewnames",    cmd_store_newname,      "NILL",             "save the aliases to a file"},
        {"readnewnames",    cmd_restore_newname,    "NILL",             "restore the aliases from a file"},
        {"help",            cmd_help,               "NILL",             "display the command supported"}
};

static bool cmd_store_newname(char **token)
{
    if(NULL == *(token+1)) {
        printf("please specify the filename where aliases should be stored\n");
        return false;
    }

    if (write_aliases_to_file(*(token+1), alias_hold) != 0) {
        printf("Failed to write aliases\n");
        return false;
    }

    return true;
}

static bool cmd_restore_newname(char **token)
{
    if (NULL == *(token+1)) {
        printf("please specify the filename from where aliases should be restored\n");
        return false;
    }

    if (read_aliases_from_file(*(token+1), alias_hold, STORE_TOTAL_ALIASES) != 0 ) {
        printf("Failed to restore the aliases from file\n");
        return false;
    }

    return true;
}

static bool cmd_newname(char** token)
{
    int ret;
    if(NULL == *(token+1) && NULL == *(token+2)) {
        printf("Enter proper alias substitution\n");
        return false;
    }

    if(NULL == *(token+2) && *(token+1)) {
        printf("delete the correspond alias\n");
        if (delete_alias_entry(*(token+1), alias_hold, STORE_TOTAL_ALIASES) != 0 ) {
             printf("FAILED TO DELETE THE ENTRY\n");
             return false;
        }
        return true;
    }

//    printf("alias name [%s] corresponding cmd [%s]\n",*(token+1), *(token+2));

    ret = update_duplicate_entry(*(token+1), *(token+2), alias_hold, STORE_TOTAL_ALIASES);
    if(!ret) {
        printf("Updated Duplicate Entry\n");
    }
    else {
        printf("Registering new alias\n");
        register_new_alias(*(token+1), *(token+2), alias_hold, STORE_TOTAL_ALIASES);
    }

    return false;
}

static bool cmd_display_newname(char** token)
{
    aliases_hold_t *alias_ptr = NULL;
    alias_ptr = alias_hold;
//    printf("kar %s %s \n",alias_ptr->alias_name, alias_ptr->alias_eqvi_cmd);
    display_aliases(alias_hold, STORE_TOTAL_ALIASES);
    return true;
}

static bool cmd_history_execute(char** token)
{
    char *history_cmd;
    int history_num;
    int final_val;

    /* check whether it is alphabet */
    if(isalpha(*(*(token+1)))) {
        printf("Entered value is a character Enter proper value\n");
        return false;
    }

    /* converting alphabet to int */
    history_num = atoi(*(token+1));

    if(tsh_debug) {
        printf("history num is %d\n",history_num);
    }

    if (history_num > history_count || 0 == (history_count -1) || history_num <= 0) {
        printf("%s: ! %d: event not found \n",s_info.shell_name, history_num);
        return false;
    }

    if (history_num == 1 && (STORE_TOTAL_HISTORY + 1) == history_count) {
         history_cmd = preserve_string;
        printf("THIS IS TO BE EXECUTED %s\n",preserve_string);
    } else if((STORE_TOTAL_HISTORY + 1) > history_count) {
        printf("FOR STARTING\n");
        history_cmd = hist[history_num -1];
    }else {

        /* IMPLIMENT TO GET THE CURRENT HISTORY COUNT */

//        printf("current value is %d\n",current);
        final_val = (history_num -1) + (current -1);
        if(final_val >= 10) {
            final_val = final_val % STORE_TOTAL_HISTORY;
        }

//        printf("final value is %d\n",final_val);
       // history_cmd = hist[history_num - 1];
        history_cmd = hist[final_val];
    }

    int ii;

    for(ii=0; ii<10; ii++) {
        printf("history cmd id[%d] %s\n",ii,hist[ii]);
    }

    tsh_execute_command(&history_cmd,NULL);

    return true;
}

static bool cmd_history(char** token)
{
    display_history(hist, current, STORE_TOTAL_HISTORY);
    return true;
}

static bool cmd_clear_history(char** token)
{
    clear_history(hist, STORE_TOTAL_HISTORY);
    history_count = 0;
    current = 0;
    return true;
}

static bool cmd_stop(char** token)
{
    cmd_clear_history(NULL);
    exit_signal = true;
    return true;
}

static bool cmd_setshellname(char** token)
{
    if(NULL == *(token +1)) {
        printf("please enter the shellname\n");
        return false;
    }
    strncpy(s_info.shell_name, *(token+1),SHELLNAME_SIZE - 1);
    s_info.shell_name[SHELLNAME_SIZE - 1] = '\0';

    Store_Config(SHELL_CONFIG_FILE, "Shellname", s_info.shell_name);

    if(tsh_debug) {
        printf("set shell name: %s",*token);
        printf("set shell name: %s",*(token+1));
    }

    return true;
}

static bool cmd_setterminator(char** token)
{
    if(NULL == *(token +1)) {
        printf("please enter the terminator\n");
        return false;
    }
    strncpy(s_info.terminator, *(token+1), TERMINATOR_SIZE -1);
    s_info.terminator[TERMINATOR_SIZE -1] = '\0';

    Store_Config(SHELL_CONFIG_FILE, "Terminator", s_info.terminator);
    return true;
}

static bool tsh_use_linux_shell(char *line)
{
    /* we can use fork to handle the code well, NEED TO IMPLIMENT */
    if(tsh_debug) {
        log_debug("line is %s",line);
    }

    system(line);

    return true;
}

static bool cmd_help(char** token)
{
    int i,j;
    for(i=0;i<=2;i++) {
        for(j=0;j<=88;j++) {
            if(i == 0 || i == 2 ) {
                printf("-");
            }
            else if(i == 1 && j == 1) {
                printf("Command_supported\t|\targuments\t|\tDescription\t\t\t|");
            }
        }
        printf("\n");
    }
    for(i=0;i<(int)(sizeof(commands)/sizeof(command_t));i++) {
        printf("%-10s\t\t\t%s\t\t%s\n",commands[i].res_command, commands[i].arguments, commands[i].description);
    }
    for(j=0;j<=88;j++) {
        printf("-");
    }
    printf("\n");

    return true;
}

void handle_ctrl_l()
{
    /* to handle ctrl + L signal to clear the screen */
    system("clear");
}

int tsh_execute_command(char **command_entered, char *line)
{
    int search = 0;
    bool alias_found = false;
    char alias_eqvi_command[ALIAS_STR_LENGTH]= {};
    if(*command_entered == NULL) {
        if(tsh_debug) {
            log_debug("No command entered\n");
        }
        return 0;
    }

 //   printf("command entered is %s\n",*command_entered);
//    printf("line is %s\n",line);

    /* check for alias substitution and get the eqvivalent command if found*/
    if(check_cmd_is_alias(*command_entered, alias_eqvi_command, alias_hold) == 0) {
        alias_found = true;
        printf("EQVI CMD is %s\n",alias_eqvi_command);
        strcpy(*command_entered, alias_eqvi_command);
        printf("EXECUTE THIS %s\n",*command_entered);
    }
    else {
        //printf("THIS is not a alias\n");
    }

    for(search = 0; search < (int)(sizeof(commands)/sizeof(command_t)); search++) {
        if(strcmp(commands[search].res_command, *command_entered) == 0) {
            if(commands[search].funcptr(command_entered) != true ) {
                if(tsh_debug) {
                    log_err("Command execution failed");
                }
                return 1;
            }
            return 0;
        }
    }
/* To execute the alias command and the history re-execution command, if it is not a builtin command */
    if(line == NULL || alias_found) {
        tsh_use_linux_shell(*command_entered);
    }
    else
        tsh_use_linux_shell(line); /* To handle the shell command directly*/

    if(tsh_debug) {
        log_warn("\t** COMMAND NOT SUPPORTED PLEASE TRY help **");
    }
//  commands[1].funcptr(command_entered);

    return 1;
}

int tsh_split_line(char *line, char ***split)
{
    char* token;
    int position = 0, count = 0;
    *split = (char**)calloc(MAXSTRING, sizeof(char*));
    if(!split) {
        log_err("Error allocating memory");
        return 1;
    }

    token = strtok(line, "\n\r\t' '");
    while(token != NULL) {
        *(*(split)+position++) = token;
        if(tsh_debug) {
            log_debug("%s\n",token);
        }
        token = strtok(NULL, "\n\r\t' '");
    }

    return 0;
}

int tsh_read_line (char** line, int* total_char)
{
    char ch;
    int position = 0;

    *line = (char*) calloc (sizeof(char), MAXSTRING);

    if (!*line) {
        log_err(" memory allocation error");
        return 1;
    }

    for (position = 0; position < MAXSTRING;) {

        ch = getchar ();
        if(ch == 0x0C) {
            handle_ctrl_l();
            /* to read the next line char left in the buffer */
            getchar();
            /* handling -1 */
            return -1;
        }

        if('!' == ch) {
            re_execution_command = true;
        }

        if (ch == '\n') {
            *(*(line) + position) = '\0';
            *total_char = position;
            return 0;
        } else {
            *(*(line) + position) = ch;
        }
        position++;
    }

    return 0;

}
void clear_colour()
{
    /* To clear the colour */
    printf("\033[0m");

}

void clear_memory(char *line, char ***token, char* command_reserve)
{
//printf("token %p\n",*token);
    if(line) {
        free(line);
        line = NULL;
    }
    if(command_reserve) {
        free(command_reserve);
        command_reserve = NULL;
    }
    if(preserve_string) {
        free(preserve_string);
        preserve_string = NULL;
    }
    if(*token) {
        //printf("token address %x\n",token);
        free(*token);
        token = NULL;
    }

}

int Loop()
{
    char *line = NULL, **token = NULL, *command_reserve = NULL;

    int total_char = 0, cmd_num = 1, ret;
    do{

        printf("\033[1;32m%s[%d]%s ",s_info.shell_name, cmd_num, s_info.terminator);
        clear_colour();
        ret = tsh_read_line(&line, &total_char);
        if (ret) {
            if (ret != -1)
                log_warn("failed to read the line");
            continue;
        }

        command_reserve = (char*) calloc (sizeof(char), MAXSTRING);
        if(NULL == command_reserve) {
            log_err("failed to allocate memory to reserve the command");
            free(line);
            line = NULL;
            continue;
        }

        preserve_string = (char*) calloc (sizeof(char), MAXSTRING);
        if(NULL == preserve_string) {
            log_err("failed to allocate memory to preserve_string the command");
            free(line);
            line = NULL;
            continue;
        }

        /* To take a backup of the command */
        strcpy(command_reserve,line);

        if(total_char) {
            cmd_num++;

            if(history_count <= STORE_TOTAL_HISTORY)
                history_count++;
            /* This is used only when we try to execute the first history */
            if(hist[current]) {
                strcpy(preserve_string, hist[current]);
                printf("history preserved is %s\n",preserve_string);
            }
            if(!re_execution_command)
                add_history(command_reserve, hist, &current, STORE_TOTAL_HISTORY);

            re_execution_command = false;

/*            int ii;
            for(ii=0; ii<(STORE_TOTAL_HISTORY); ii++) {
                printf("history cmd old id[%d] %s\n",ii,hist[ii]);
            }*/
        }

        if(tsh_debug) {
            log_debug("entered command is %s",line);
        }

        if(tsh_split_line(line, &token) != 0) {
            log_warn("failed to get token");
            /* we dont loose the commnad */
#if 0
            if(line) {
                free(line);
                line = NULL;
            }
            if(command_reserve) {
                free(command_reserve);
                command_reserve = NULL;
            }
            if(preserve_string) {
                free(preserve_string);
                preserve_string = NULL;
            }
#endif
            clear_memory(line, &token, command_reserve);
            continue;
        }

        if(tsh_debug && total_char) {
            log_debug("%s\n",*token);
            //printf("%s\n",*(token + 1));
        }

        if(tsh_execute_command(token, command_reserve) != 0) {
            if(tsh_debug) {
                log_warn("failed to execute the command");
            }
        }
        clear_memory(line, &token, command_reserve);
#if 0
        if(line) {
            free(line);
            line = NULL;
        }
        if(command_reserve) {
            free(command_reserve);
            command_reserve = NULL;
        }
        if(preserve_string) {
            free(preserve_string);
            preserve_string = NULL;
        }
        if(token) {
            //printf("token address %x\n",token);
            free(token);
            token = NULL;
        }
#endif
        //printf("\n");
    }while(!exit_signal);

    return 1;

}

void Emblem()
{
   printf("\t\t\t \033[0;32m WELCOME TO %s\n", s_info.shell_name);
   /* To reset the colour */
   printf("\033[0m");
}

void InitShell()
{
    if (0 != Restore_Config(&s_info, SHELL_CONFIG_FILE)) {
        printf("Failed to restore config file\n");
    }

    if(CLEAR_SCREEN_WITH_HISTORY) {
        system("clear");
        usleep(10000);
    } else {
        ClearScreen();
    }

    Emblem();
}

void Shell_Debug(bool debug)
{
    tsh_debug = debug;

}

void Start()
{
    Shell_Debug(false);
    InitShell();
    Loop();

}

void Stop()
{

}

