/**
 * @file shell-main.cpp
 * @brief shell-main.cpp
 * @author
 * @date 06-Sep-2019
 */

/***************************************************************************
 * headers
 ***************************************************************************/
#include <stdio.h>
#include <signal.h>
#include <unistd.h>

#include "shell.h"

/***************************************************************************
 * functions
 ***************************************************************************/

void sig_handler(int sig)
{
//    printf("Caught signal %d\n", sig);
}

int main(int argc, char **argv)
{

    printf("starting shell\n");

    signal(SIGTERM, sig_handler);
    signal(SIGINT, sig_handler);
    signal(SIGKILL, sig_handler);
    signal(SIGTSTP, sig_handler);

    Start();

    Stop();

    printf("stopped shell\n");

    return 0;
}



