/**
 * @file file.c
 * @brief file.c
 * @author
 * @date 11-Sep-2019
 *
 */

/** NEED TO IMPLIMENT */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdbool.h>
#include <string.h>

#include "file.h"
#include "iniparser.h"
#include "dictionary.h"

#if 0
int File_Init(file_t *file)
{
    file->fp = fopen(file->filename, "w");
    if(NULL == file->fp) {
        printf("Failed to open the file");
        return 1;
    }

    return 0;
}

#endif

int Store_Config(char *shell_config_file, char *type, char *data)
{
    dictionary  *ini;
    char val[24], str[32];
    FILE *fp;

    ini = iniparser_load(shell_config_file);
    if (NULL == ini) {
        printf("cannot parse file: %s\n", shell_config_file);
        return 1 ;
    }
    //printf("filename %s type %s data %s \n",shell_config_file, type, data);

    snprintf(str, 32, "Shell:%s",type);

    if( 0 != iniparser_set(ini, (const char*)str, data)) {
        printf("failed to set new value\n");
        return 1;
    }

    if(!(fp = fopen(shell_config_file, "w"))){
        printf("File open error %s\n",shell_config_file);
        return 1;
    }

    iniparser_dump_ini(ini, fp);
    iniparser_freedict(ini);
    fclose(fp);

    return 0;
}

static int parse_ini_file(shell_info_t *shell_info, char *shell_config_file)
{
    dictionary  *ini;
    const char* read_string;

    ini = iniparser_load(shell_config_file);
    if (NULL == ini) {
        printf("cannot parse file: %s\n", shell_config_file);
        return 1 ;
    }

    read_string = iniparser_getstring(ini, "Shell:Shellname", NULL);
    strcpy(shell_info->shell_name, read_string);

    read_string = iniparser_getstring(ini, "Shell:Terminator", NULL);
    strcpy(shell_info->terminator, read_string);

    iniparser_freedict(ini);

    return 0;
}

void save_default_config(FILE *ini)
{
    fprintf(ini,
    "#\n"
    "# This is shell config ini file\n"
    "#\n"
    "\n"
    "[Shell]\n"
    "\n"
    "Shellname       = toyshell\n"
    "Terminator      = >\n"
    "\n");

}

int Restore_Config(shell_info_t *shell_info, char* shell_config_file)
{
    int ret;
    if (0 != access(shell_config_file, F_OK)) {
        FILE *ini;
        if ( NULL == (ini=fopen(shell_config_file, "w"))) {
            printf("iniparser: cannot create %s\n",shell_config_file);
            return 1;
        }
        save_default_config(ini);
        fclose(ini);
    }

    if (0 != parse_ini_file(shell_info, shell_config_file)) {
        printf("failed to parse shell config file\n");
        return 1;
    }

    return 0;
}

