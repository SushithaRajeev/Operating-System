/**
 * @file history.h
 * @brief history.h
 * @author
 * @date 10-Sep-2019
 *
 */


#ifndef HISTORY_H_
#define HISTORY_H_

#ifdef __cplusplus
extern "C" {
#endif

void add_history(char *line, char *hist[], int *current, int history_length);
void display_history(char *hist[], int current, int history_length);
void clear_history(char *hist[], int history_length);

#ifdef __cplusplus
}
#endif

#endif /* HISTORY_H_ */
