/**
 * @file file.h
 * @brief file.h
 * @author
 * @date 11-Sep-2019
 */


#ifndef FILE_H_
#define FILE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "shell.h"

typedef struct {
    FILE *fp;
    char *filename;

} file_t;

int File_Init(file_t *file);
int Restore_Config(shell_info_t *shell_info, char* shell_config_file);
int Store_Config(char *shell_config_file, char *type, char *data);


#ifdef __cplusplus
}
#endif

#endif /* FILE_H_ */
