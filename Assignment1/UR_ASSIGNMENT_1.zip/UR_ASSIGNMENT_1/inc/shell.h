/**
 * @file shell.h
 * @brief shell.h
 * @author
 * @date 06-Sep-2019
 *
 */

#ifndef SHELL_H_
#define SHELL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>


/***************************************************************************
 * constants
 ***************************************************************************/
#define POLLDELAY                   100                             //!< main loop delay in ms
#define MAXSTRING                   256                             //!< maximun input string that can be processed
#define ClearScreen()               printf("\033[H\033[J")

#define CLEAR_SCREEN_WITH_HISTORY   true                            //!< clears screen with history
#define STORE_TOTAL_HISTORY         10
#define STORE_TOTAL_ALIASES         10
#define TERMINATOR_SIZE             8
#define SHELLNAME_SIZE              16
#define SHELL_CONFIG_FILE           "./shell_config.ini"
/***************************************************************************
 * typedefs
 ***************************************************************************/
typedef struct {
    char*       res_command;
    bool        (*funcptr)(char** token);
    char*       arguments;
    const char* description;
} command_t;

typedef struct {
    char terminator[TERMINATOR_SIZE];
    char shell_name[SHELLNAME_SIZE];
} shell_info_t;
/***************************************************************************
 * class definition
 ***************************************************************************/

static bool cmd_stop(char** token);
static bool cmd_setshellname(char** token);
static bool cmd_setterminator(char** token);
static bool cmd_help(char** token);
static bool cmd_history(char** token);
static bool cmd_clear_history(char** token);
static bool cmd_history_execute(char** token);
static bool cmd_newname(char** token);
static bool cmd_display_newname(char** token);
static bool cmd_store_newname(char **token);
static bool cmd_restore_newname(char **token);
int tsh_execute_command(char **command_entered, char *line);


/**
 *  @brief Shell Results
 */
enum Result {
    kOK = 0,                    //!< OK
};

/**
 * @brief start the app
 * @return kOK if success otherwise fail
 */
void Start();

/**
 * @brief stop the app
 */
void Stop();

#ifdef __cplusplus
}
#endif

#endif /* SHELL_H_ */
