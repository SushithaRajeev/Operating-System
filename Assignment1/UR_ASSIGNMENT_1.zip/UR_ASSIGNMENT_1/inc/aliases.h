/**
 * @file aliases.h
 * @brief aliases.h
 * @author
 * @date 17-Sep-2019l
 *
 */


#ifndef ALIASES_H_
#define ALIASES_H_

#ifdef __cplusplus
extern "C" {
#endif

#define ALIAS_STR_LENGTH                24

typedef struct {
    int id;
    char alias_name[ALIAS_STR_LENGTH];
    char alias_eqvi_cmd[ALIAS_STR_LENGTH];
} aliases_hold_t;

int update_duplicate_entry(char *alias_name, char *alias_eqvi_name, aliases_hold_t *alias_hold, int total_entries);
int register_new_alias(char *alias_name, char *alias_eqvi_name, aliases_hold_t *alias_hold, int total_entries);
void display_aliases(aliases_hold_t *alias_hold, int total_entries);
int delete_alias_entry(char *alias_del, aliases_hold_t *alias_hold, int total_entries);
int check_cmd_is_alias(char *cmd, char *alias_eqvi_command, aliases_hold_t *alias_hold);
int write_aliases_to_file(char *filename, aliases_hold_t *alias_hold);
int read_aliases_from_file(char *filename, aliases_hold_t *alias_hold, int total_entries);

#ifdef __cplusplus
}
#endif

#endif /* ALIASES_H_ */
