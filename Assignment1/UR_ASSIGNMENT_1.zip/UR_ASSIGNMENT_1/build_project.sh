#!/bin/bash
# Name: build_project.sh
# Creator: 
# Description: builds shell project


gcc -g $PWD/src/*.c -I$PWD/inc -I$PWD/lib/x86/inc -L$PWD/lib/x86/lib -liniparser -o myshell
